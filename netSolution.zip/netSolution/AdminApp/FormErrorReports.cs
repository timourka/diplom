﻿using Contracts.Dtos;

namespace AdminApp;

public class FormErrorReports : Form
{
    private readonly AdminApiClient _api;

    private readonly DataGridView _grid = new();
    private readonly Button _btnRefresh = new();
    private readonly Button _btnOpen = new();

    private readonly BindingSource _binding = new();

    public FormErrorReports(AdminApiClient api)
    {
        _api = api;

        Text = "Сообщения об ошибках";
        Width = 900;
        Height = 600;
        StartPosition = FormStartPosition.CenterParent;

        _grid.Dock = DockStyle.Top;
        _grid.Height = 480;
        _grid.ReadOnly = true;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.MultiSelect = false;
        _grid.AutoGenerateColumns = false;
        _grid.AllowUserToAddRows = false;
        _grid.AllowUserToDeleteRows = false;

        _grid.Columns.Add(new DataGridViewTextBoxColumn
        {
            HeaderText = "Id",
            DataPropertyName = "Id",
            Width = 80
        });

        _grid.Columns.Add(new DataGridViewTextBoxColumn
        {
            HeaderText = "UserId",
            DataPropertyName = "UserId",
            Width = 80
        });

        _grid.Columns.Add(new DataGridViewTextBoxColumn
        {
            HeaderText = "Дата",
            DataPropertyName = "CreatedAt",
            Width = 200
        });

        _grid.Columns.Add(new DataGridViewTextBoxColumn
        {
            HeaderText = "Кол-во кадров",
            DataPropertyName = "FramesCount",
            Width = 120
        });

        _grid.Columns.Add(new DataGridViewCheckBoxColumn
        {
            HeaderText = "Approved",
            DataPropertyName = "Approved",
            Width = 90
        });

        _grid.DataSource = _binding;
        _grid.DoubleClick += (_, _) => OpenSelected();

        _btnRefresh.Text = "Обновить";
        _btnRefresh.Width = 120;
        _btnRefresh.Height = 35;
        _btnRefresh.Location = new Point(20, 500);
        _btnRefresh.Click += async (_, _) => await LoadReportsAsync();

        _btnOpen.Text = "Открыть подробнее";
        _btnOpen.Width = 180;
        _btnOpen.Height = 35;
        _btnOpen.Location = new Point(160, 500);
        _btnOpen.Click += (_, _) => OpenSelected();

        Controls.Add(_grid);
        Controls.Add(_btnRefresh);
        Controls.Add(_btnOpen);

        Shown += async (_, _) => await LoadReportsAsync();
    }

    private async Task LoadReportsAsync()
    {
        try
        {
            UseWaitCursor = true;
            var items = await _api.GetErrorReportsAsync();
            _binding.DataSource = items;
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            UseWaitCursor = false;
        }
    }

    private void OpenSelected()
    {
        if (_binding.Current is not AdminErrorReportListItemDto item)
            return;

        var form = new FormErrorReportDetails(_api, item.Id);
        form.ShowDialog(this);
    }
}