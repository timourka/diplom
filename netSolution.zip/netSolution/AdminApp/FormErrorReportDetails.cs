﻿using Contracts.Dtos;

namespace AdminApp;

public class FormErrorReportDetails : Form
{
    private readonly AdminApiClient _api;
    private readonly int _reportId;

    private AdminErrorReportDetailsDto? _report;
    private int _currentFrameIndex = 1;

    private readonly Label _lblInfo = new();
    private readonly Label _lblFrameNumber = new();
    private readonly TextBox _txtComment = new();

    private readonly PictureBox _pictureBox = new();

    private readonly Button _btnPrev = new();
    private readonly Button _btnNext = new();
    private readonly Button _btnApprove = new();
    private readonly Button _btnDelete = new();
    private readonly Button _btnBlockUser = new();
    private readonly Button _btnRefresh = new();

    private Image? _currentImage;
    private YoloBboxDto? _currentBbox;

    public FormErrorReportDetails(AdminApiClient api, int reportId)
    {
        _api = api;
        _reportId = reportId;

        Text = $"Сообщение #{reportId}";
        Width = 1100;
        Height = 850;
        StartPosition = FormStartPosition.CenterParent;

        _lblInfo.AutoSize = false;
        _lblInfo.Width = 1040;
        _lblInfo.Height = 80;
        _lblInfo.Location = new Point(20, 20);
        _lblInfo.Font = new Font("Segoe UI", 10, FontStyle.Regular);

        _txtComment.Location = new Point(20, 110);
        _txtComment.Width = 1040;
        _txtComment.Height = 70;
        _txtComment.Multiline = true;
        _txtComment.ReadOnly = true;

        _pictureBox.Location = new Point(20, 200);
        _pictureBox.Width = 800;
        _pictureBox.Height = 600;
        _pictureBox.BorderStyle = BorderStyle.FixedSingle;
        _pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
        _pictureBox.Paint += PictureBox_Paint;

        _lblFrameNumber.Location = new Point(840, 220);
        _lblFrameNumber.Width = 220;
        _lblFrameNumber.Height = 30;
        _lblFrameNumber.Font = new Font("Segoe UI", 10, FontStyle.Bold);

        _btnPrev.Text = "←";
        _btnPrev.Width = 80;
        _btnPrev.Height = 40;
        _btnPrev.Location = new Point(840, 270);
        _btnPrev.Click += async (_, _) =>
        {
            if (_report is null || _currentFrameIndex <= 1) return;
            _currentFrameIndex--;
            await LoadFrameAsync();
        };

        _btnNext.Text = "→";
        _btnNext.Width = 80;
        _btnNext.Height = 40;
        _btnNext.Location = new Point(940, 270);
        _btnNext.Click += async (_, _) =>
        {
            if (_report is null || _currentFrameIndex >= _report.FramesCount) return;
            _currentFrameIndex++;
            await LoadFrameAsync();
        };

        _btnApprove.Text = "Approve / Unapprove";
        _btnApprove.Width = 220;
        _btnApprove.Height = 40;
        _btnApprove.Location = new Point(840, 350);
        _btnApprove.Click += async (_, _) => await ToggleApproveAsync();

        _btnDelete.Text = "Удалить репорт";
        _btnDelete.Width = 220;
        _btnDelete.Height = 40;
        _btnDelete.Location = new Point(840, 410);
        _btnDelete.Click += async (_, _) => await DeleteReportAsync();

        _btnBlockUser.Text = "Заблокировать пользователя";
        _btnBlockUser.Width = 220;
        _btnBlockUser.Height = 40;
        _btnBlockUser.Location = new Point(840, 470);
        _btnBlockUser.Click += async (_, _) => await BlockUserAsync();

        _btnRefresh.Text = "Обновить";
        _btnRefresh.Width = 220;
        _btnRefresh.Height = 40;
        _btnRefresh.Location = new Point(840, 530);
        _btnRefresh.Click += async (_, _) => await LoadAllAsync();

        Controls.Add(_lblInfo);
        Controls.Add(_txtComment);
        Controls.Add(_pictureBox);
        Controls.Add(_lblFrameNumber);
        Controls.Add(_btnPrev);
        Controls.Add(_btnNext);
        Controls.Add(_btnApprove);
        Controls.Add(_btnDelete);
        Controls.Add(_btnBlockUser);
        Controls.Add(_btnRefresh);

        Shown += async (_, _) => await LoadAllAsync();
    }

    private async Task LoadAllAsync()
    {
        try
        {
            UseWaitCursor = true;

            _report = await _api.GetErrorReportAsync(_reportId);
            if (_report == null)
            {
                MessageBox.Show(this, "Репорт не найден", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
                return;
            }

            if (_currentFrameIndex < 1) _currentFrameIndex = 1;
            if (_currentFrameIndex > _report.FramesCount) _currentFrameIndex = _report.FramesCount;

            _lblInfo.Text =
                $"ReportId: {_report.Id}\r\n" +
                $"UserId: {_report.UserId}\r\n" +
                $"CreatedAt: {_report.CreatedAt}\r\n" +
                $"FramesCount: {_report.FramesCount}\r\n" +
                $"Approved: {_report.Approved}";

            _txtComment.Text = _report.Comment ?? "";

            await LoadFrameAsync();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            UseWaitCursor = false;
        }
    }

    private async Task LoadFrameAsync()
    {
        if (_report == null) return;

        try
        {
            UseWaitCursor = true;

            _currentImage?.Dispose();
            _currentImage = await _api.GetFrameImageAsync(_report.Id, _currentFrameIndex);
            _currentBbox = await _api.GetFrameBboxAsync(_report.Id, _currentFrameIndex);

            _pictureBox.Image = _currentImage;
            _lblFrameNumber.Text = $"Кадр {_currentFrameIndex} / {_report.FramesCount}";

            _pictureBox.Invalidate();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка загрузки кадра",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            UseWaitCursor = false;
        }
    }

    private async Task ToggleApproveAsync()
    {
        if (_report == null) return;

        try
        {
            var newValue = !_report.Approved;
            await _api.SetReportApprovedAsync(_report.Id, newValue);
            await LoadAllAsync();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task DeleteReportAsync()
    {
        if (_report == null) return;

        var confirm = MessageBox.Show(
            this,
            $"Удалить репорт #{_report.Id}?",
            "Подтверждение",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning);

        if (confirm != DialogResult.Yes)
            return;

        try
        {
            await _api.DeleteReportAsync(_report.Id);
            MessageBox.Show(this, "Репорт удалён", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка удаления", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task BlockUserAsync()
    {
        if (_report == null) return;

        var confirm = MessageBox.Show(
            this,
            $"Заблокировать пользователя #{_report.UserId}?",
            "Подтверждение",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning);

        if (confirm != DialogResult.Yes)
            return;

        try
        {
            await _api.BlockUserAsync(_report.UserId, true);
            MessageBox.Show(this, "Пользователь заблокирован", "OK",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка блокировки", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void PictureBox_Paint(object? sender, PaintEventArgs e)
    {
        if (_pictureBox.Image == null || _currentBbox == null)
            return;

        var img = _pictureBox.Image;

        // прямоугольник в координатах исходного изображения
        var imgW = img.Width;
        var imgH = img.Height;

        var bboxW = (float)(_currentBbox.W * imgW);
        var bboxH = (float)(_currentBbox.H * imgH);
        var centerX = (float)(_currentBbox.Xc * imgW);
        var centerY = (float)(_currentBbox.Yc * imgH);

        var left = centerX - bboxW / 2f;
        var top = centerY - bboxH / 2f;

        // преобразуем координаты изображения в координаты PictureBox при SizeMode.Zoom
        var rect = GetImageDisplayRectangle(_pictureBox);

        float scaleX = rect.Width / (float)imgW;
        float scaleY = rect.Height / (float)imgH;

        var drawLeft = rect.X + left * scaleX;
        var drawTop = rect.Y + top * scaleY;
        var drawWidth = bboxW * scaleX;
        var drawHeight = bboxH * scaleY;

        using var pen = new Pen(Color.Red, 3);
        e.Graphics.DrawRectangle(pen, drawLeft, drawTop, drawWidth, drawHeight);
    }

    private static Rectangle GetImageDisplayRectangle(PictureBox pb)
    {
        if (pb.Image == null)
            return pb.ClientRectangle;

        var img = pb.Image;
        float imageRatio = (float)img.Width / img.Height;
        float boxRatio = (float)pb.ClientSize.Width / pb.ClientSize.Height;

        if (imageRatio > boxRatio)
        {
            int width = pb.ClientSize.Width;
            int height = (int)(width / imageRatio);
            int top = (pb.ClientSize.Height - height) / 2;
            return new Rectangle(0, top, width, height);
        }
        else
        {
            int height = pb.ClientSize.Height;
            int width = (int)(height * imageRatio);
            int left = (pb.ClientSize.Width - width) / 2;
            return new Rectangle(left, 0, width, height);
        }
    }
}