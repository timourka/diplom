﻿using System.Windows.Forms;

namespace AdminApp;

public class FormMain : Form
{
    private readonly string _token;
    private readonly AdminApiClient _api;

    private readonly Button _btnErrorReports = new();
    private readonly Label _lblTitle = new();

    public FormMain(string token)
    {
        _token = token;
        _api = new AdminApiClient("http://localhost:5099/", _token);

        Text = "Админка";
        Width = 500;
        Height = 250;
        StartPosition = FormStartPosition.CenterScreen;

        _lblTitle.Text = "Панель администратора";
        _lblTitle.AutoSize = true;
        _lblTitle.Font = new Font("Segoe UI", 16, FontStyle.Bold);
        _lblTitle.Location = new Point(20, 20);

        _btnErrorReports.Text = "Сообщения об ошибках";
        _btnErrorReports.Width = 220;
        _btnErrorReports.Height = 50;
        _btnErrorReports.Location = new Point(20, 80);
        _btnErrorReports.Click += (_, _) =>
        {
            var form = new FormErrorReports(_api);
            form.ShowDialog(this);
        };

        Controls.Add(_lblTitle);
        Controls.Add(_btnErrorReports);
    }
}