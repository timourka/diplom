import 'package:flutter/material.dart';

import '../api/api_client.dart';
import '../auth/auth_state.dart';

class ManualAddSheet extends StatefulWidget {
  final AuthState auth;
  const ManualAddSheet({super.key, required this.auth});

  @override
  State<ManualAddSheet> createState() => _ManualAddSheetState();
}

class _ManualAddSheetState extends State<ManualAddSheet> {
  final _nameController = TextEditingController();
  DateTime? _expiry;

  String? _error;
  bool _saving = false;

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      firstDate: now.subtract(const Duration(days: 1)),
      lastDate: now.add(const Duration(days: 3650)),
      initialDate: _expiry ?? now.add(const Duration(days: 7)),
    );
    if (picked != null) setState(() => _expiry = picked);
  }

  Future<void> _save() async {
    final productName = _nameController.text.trim();

    if (productName.isEmpty) {
      setState(() => _error = 'Введи название продукта');
      return;
    }

    if (_expiry == null) {
      setState(() => _error = 'Выбери срок годности');
      return;
    }

    setState(() {
      _error = null;
      _saving = true;
    });

    try {
      final api = ApiClient(token: widget.auth.token);
      await api.addStoredProductByName(productName, _expiry!);
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + pad),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Добавить продукт',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            if (_error != null) ...[
              Text(_error!, style: const TextStyle(color: Colors.red)),
              const SizedBox(height: 8),
            ],
            TextField(
              controller: _nameController,
              textInputAction: TextInputAction.done,
              decoration: const InputDecoration(
                labelText: 'Название продукта',
                hintText: 'Например: молоко, йогурт, сыр',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _saving ? null : _pickDate,
              icon: const Icon(Icons.calendar_month),
              label: Text(
                _expiry == null
                    ? 'Выбрать срок годности'
                    : 'Срок годности: ${_expiry!.toLocal().toString().split(' ').first}',
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: _saving ? null : _save,
              icon: _saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.save),
              label: Text(_saving ? 'Сохраняем...' : 'Добавить в личный кабинет'),
            ),
          ],
        ),
      ),
    );
  }
}
